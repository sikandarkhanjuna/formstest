
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>User Form</title>
  </head>




  
  <body>
   



<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(action('App\Http\Controllers\UserformController@store')); ?>" method="POST">

<?php echo e(csrf_field()); ?>


      <div class="modal-body">
      <div class="form-group">
    <label>First Name</label>
    <input type="text" class="form-control" value="<?php echo e(old('fname')); ?>"  pattern="[A-Za-z]{1,32}" name="fname"  placeholder="Enter First Name"required>
     
    
  <span class="text-danger">
 <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <?php echo e($message); ?>

    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


    
    </span>  
 


  </div>      

  <div class="form-group">
    <label>Last Name</label>
    <input type="text" class="form-control" name="lname" pattern="[A-Za-z]{1,32}" value="<?php echo e(old('fname')); ?>" placeholder="Enter Last Name"/>
  
    <span class="text-danger">
 <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <?php echo e($message); ?>


    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </span>
  
  </div>

  <div class="form-group">
    <label>Address</label>
    <input type="text" class="form-control" pattern="[A-Za-z0-9_]{1,15}" name="address" value="<?php echo e(old('fname')); ?>" placeholder="Enter Address"required/>
  
  
    <span class="text-danger">
 <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <?php echo e($message); ?>

    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </span>
  
  
  
  </div>

  <div class="form-group">
    <label>Mobile</label>
    <input type="number" class="form-control" name="mobile" value="<?php echo e(old('fname')); ?>" placeholder="Enter Mobile Number" required/>
 
    <span class="text-danger">
 
 
    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <?php echo e($message); ?>


    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </span>
 
 
  </div>

      </div>

      <div class="form-group">

<label for="Date">Birthday:</label>
<input type="date" id="" name="date"Required>
</div>

<!----<div class="form-group">

  <input type="radio" id="" name="html" value="HTML">
  <label for="html">HTML</label><br>
  <input type="radio" id="" name="css" value="CSS">
  <label for="css">CSS</label><br>
  <input type="radio" id="" name="js" value="JavaScript">
  <label for="javascript">JavaScript</label>
</div>------>


      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save Data</button>
      </div>


      </form>

<?php if(session()->has('status')): ?>
<div class="alert- alert-success">

<?php echo e(session('status')); ?>

</div>
<?php endif; ?>
    </div>
  </div>
</div>




<div class="container">
    <h1> User Form ( CRUD With Bootstrap) </h1>
    
    <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
 <ul> 
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </ul>
 
    </div>
    <?php endif; ?>
    
<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Launch demo modal
</button>


</div>
    
<h1>Data Base User's List</h1>




<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>






  </body>
</html><?php /**PATH C:\Users\HP\testform\resources\views/form.blade.php ENDPATH**/ ?>