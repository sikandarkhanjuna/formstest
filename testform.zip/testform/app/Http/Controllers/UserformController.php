<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Userform as ModelsUserform;

use Illuminate\Http\Request;
use App\Userform;
class UserformController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         

        return view('form');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // validate these form fields


        $this->validate($request,[
        'fname' => 'required',
        'lname' => 'required',
        'address' => 'required',
        'mobile' => 'required',
        
    ]);
     // insert query 
        $users = new ModelsUserform();
           $users->fname = $request->input('fname');
           $users->lname = $request->input('lname');
           $users->address = $request->input('address');
           $users->mobile = $request->input('mobile');
           $users->date = $request->input('date');
           $users->save();


           //return redirect (route('/view'))->with('status', 'Data Added Successfuly');



          return redirect('/view')->with('status', 'Data Added Successfuly');
    }
    

public function delete()
{
    
}

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    function show()
    {
        {
            $data= ModelsUserform::all();
            return view('/view',['userforms'=>$data]);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
