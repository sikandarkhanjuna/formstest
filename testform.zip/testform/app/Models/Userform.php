<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Userform extends Model
{
    use HasFactory;
    use SoftDeletes;
// Mutator function for capitilize ist charecter of fname change at run time 
    public function setfnameAttribute($value){
        $this->attributes['fname']=ucwords($value);

    }
}